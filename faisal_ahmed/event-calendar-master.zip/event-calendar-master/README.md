# event-calendar
### Used Technologies
 Frontend
  - Reactjs,redux, redux-thunk, localstorage, bootstrap
##  Features
      - Create event (each event will have a color code assigned to it)
      - Edit event
      - Delete a event
# Build instruction
1.  clone the repo
2.  run `npm install`

# Project Demo
<a href="https://imgflip.com/gif/2kxwik"><img src="https://i.imgflip.com/2kxwik.gif" title="made at imgflip.com"/></a>


