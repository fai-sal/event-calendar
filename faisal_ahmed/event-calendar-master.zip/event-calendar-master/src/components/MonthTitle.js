import React from 'react'
import { Col } from 'reactstrap'
export default () => {
    return <Col className="col-sm-12 col-md-6 col-lg-6 col-xl-6" >
        <h1 className="monthName">September</h1>
    </Col>
}